
Syllable Slam Etude 2  
Enter in a word, and it will be counted for syllables and output however many it detects.  

We based this off of the written rules for syllables.
<https://profgwhitehead.weebly.com/uploads/4/7/9/3/47931813/how_to_count_syllables.pdf>


Count the number of vowels (A,E,I,O,U) in the word.
- Add 1 every time the letter 'y' makes the sound of a vowels  
- Subtract 1 for each silent vowel  
Subtract 1 for each diphthong or triphthong in the word  

Group Members:  
Cameron Moore-Carter 3270737  
Jakub Sawicki 5580766  
Remin Reji Matthew 2581103  
Yashna Shetty 2901410  
